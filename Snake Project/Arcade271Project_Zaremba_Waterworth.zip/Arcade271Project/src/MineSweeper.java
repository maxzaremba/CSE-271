import java.util.Arrays;
import java.util.Scanner;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.MouseInfo;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.text.ParseException;

import javax.swing.*;


public class MineSweeper extends Arcade implements MouseListener, KeyListener
{
	/**
	 * 
	 */
	Graphics frame;
	/**
	 * the window width
	 */
	private int width = 1800;
	/**
	 * the window height
	 */
	private int height = 900;
	/**
	 * the starting column
	 */
	private int startcol = -1;
	/**
	 * the starting row
	 */
	private int startrow = -1;
	/**
	 * the number of rows in the grid
	 */
	private int numrows = 30;
	/**
	 * the number of columns in the grid
	 */
	private int numcols = 30;
	/**
	 * the size of the boxes
	 */
	private int boxs = 30;
	/**
	 * the number of mines to be placed
	 */
	private int nummines = 50;
	/**
	 * the x coordinate of the mouse click
	 */
	private int selectX;
	/**
	 * the y coordinates of the mouse click
	 */
	private int selectY;
	/**
	 * the color gray
	 */
	private Color gray = new Color(100,100,100);
	/**
	 * 2d array to store mine locations
	 */
	private boolean[][] minethere;
	/**
	 * 2d array to store checked boolean values
	 */
	private boolean[][] checked;
	/**
	 * 2d array to store x coords
	 */
	private int[][] xcoords;
	/**
	 * 2d array to store y coords
	 */
	private int[][] ycoords;
	/**
	 * 2d array to store flagged boolean values
	 */
	private boolean[][] flagged;
	/**
	 * boolean to see if the user has set up their choices
	 */
	private boolean setupchoices = false;
	/**
	 * boolean to see if the grid has been set
	 */
	private boolean grid = false;
	/**
	 * boolean to see if the user has clicked into the grid yet
	 */
	private boolean userclicked = false;
	/**
	 * boolean to see if the mine locations have been set
	 */
	private boolean minesset = false;
	/**
	 * boolean to see if the paint needs to be updated
	 */
	private boolean update = false;
	/**
	 * boolean to see if the user has clicked a mine
	 */
	private boolean clickedmine = false;
	/**
	 * boolean to see if the game is a success
	 */
	private boolean gamesuccess = false;
	/**
	 * boolean to see if the space bar has been pressed (or a flag needs to be placed)
	 */
	private boolean spacepressed = false;
	/**
	 * boolean to see if there needs to be a click (for placing flags)
	 */
	private boolean needsclicked = false;
	/**
	 * String that is the end status that is printed before the play again prompt on the dialog box
	 */
	private String endstatus = "";
	/**
	 * int that represents the x of the current clicked box
	 */
	private int curboxx = -1;
	/**
	 * int that represents the y of the current clicked box
	 */
	private int curboxy = -1;
	/**
	 * the factor that represents the minimum number of mines recommended (not used in this version)
	 */
	private double minelowfact = 0.1;
	/**
	 * the factor that represents the maximum number of mines recommended (not used in this version)
	 */
	private double minehighfact = 0.25;
	/**
	 * The constructor - Sets the frame settings, background color, what the frame does when it closes, and makes it visible on screen
	 */
	public MineSweeper()
	{
		pack();
		setSize(width,height);
		setBackground(Color.BLACK);
		addKeyListener(this);
		setVisible(false);
		super.setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		repaint();
	}

	/**
	 * sets up the number of rows, columns, and mines
	 */
	public void setup()
	{
		int temprows = 20;
		int tempcols = 20;
		int tempmines = 50;
		
		numrows = temprows;
		numcols = tempcols;
		nummines = tempmines;
		setupchoices = true;
		minethere = new boolean[numcols][numrows];
		checked = new boolean[numcols][numrows];
		xcoords = new int[numrows][numcols];
		ycoords = new int[numrows][numcols];
		flagged = new boolean[numrows][numcols];
		/*
		 * Sets all checked, flagged, and minethere to false
		 */
		for(int r = 0; r<numrows; r++)
		{
			for (int c = 0; c<numcols; c++)
			{
				minethere[r][c] = false;
				checked[r][c] = false;
				flagged[r][c] = false;
			}
		}
		
	}
	/**
	 * places the mines in the grid
	 * @param window the graphics window
	 */
	public void placeMines(Graphics window)
	{
		if(userclicked && !minesset)
		{
			minesset = true;
			for(int minestoplace = nummines; minestoplace>0; minestoplace--)
			{
				int tempcol = (int)(Math.random()*(numcols));
				int temprow = (int)(Math.random()*(numrows));
				if((tempcol < startcol-1) || (tempcol > startcol+1) || (temprow < startrow-1) || (temprow > startrow+1))
				{
					if(!minethere[tempcol][temprow])
					{
						minethere[tempcol][temprow] = true;
					}
					else {minestoplace++;}
				}
				else{minestoplace++;}
			}
		}
		
	}
	/**
	 * makes the grid for the player to see
	 * @param window the graphics window
	 */
	public void makeGrid(Graphics window)
	{
		//paints the grid
		window.setColor(gray);
		for(int rows = 0; rows<numrows; rows++)
		{
			for(int cols = 0; cols<numcols; cols++)
			{
				int xcoord = cols*boxs+width/2-numcols*25/2;
				int ycoord = rows*boxs+50;
				window.drawRect(xcoord, ycoord, boxs, boxs);
				if(!grid)
				{
					xcoords[rows][cols] = xcoord;
					ycoords[rows][cols] = ycoord;
				}
			}
		}
		grid = true;
	}
	/**
	 *is responsible for handling the GUI of the program
	 */
	public void paint(Graphics window)
	{
		frame = window;
		if(setupchoices == false)
		{
			setup();
		}
		if(setupchoices == true && !grid)
		{
			makeGrid(window);
		}
		if(setupchoices && grid && userclicked && !minesset)
		{
			placeMines(frame);
			showTiles(frame, startcol, startrow);
			makeGrid(window);
		}
		if(update == true)
		{
			update = false;
			if(spacepressed)
			{
				placeFlag(window);
			}
			else
			{
				showTiles(frame, curboxx, curboxy);
			}
			makeGrid(window);
		}
		if (spacepressed)
		{
			placeFlag(window);
		}

		window.setColor(gray);
		if(clickedmine == true)
		{
			clickedMine(window);
			endGame(window);
		}
		gamesuccess = checkComplete();
		if(gamesuccess == true)
		{
			gameComplete(window);
		}
	}
	/**
	 * places flags when prompted to by a right click
	 * @param window the graphics window
	 */
	public void placeFlag(Graphics window)
	{
		//places a flag so that the player can't click on a tile, such as when a player thinks that a mine is under that tile
		if(!checked[curboxy][curboxx] && !needsclicked)
		{
			if(flagged[curboxx][curboxy])
			{
				flagged[curboxx][curboxy] = false;
				window.setColor(Color.BLACK);
				window.fillRect(xcoords[curboxy][curboxx], ycoords[curboxy][curboxx], boxs, boxs);
			}
			else
			{
				flagged[curboxx][curboxy] = true;
				window.setColor(Color.WHITE);
				window.fillRect(xcoords[curboxy][curboxx], ycoords[curboxy][curboxx], boxs, boxs);
			}
		}
		needsclicked = false;
		spacepressed = false;
	}
	/**
	 * @param window the graphics window
	 * @param col a column number in the grid
	 * @param row a row number in the grid
	 */
	public void showTiles(Graphics window, int col, int row)
	{
		//if it is a mine and there is no flag present, then they clicked a mine...
		if(isMine(col, row) && !flagged[col][row])
		{
			clickedmine = true;
		}
		//if not already checked and not flagged
		if(!checked[row][col] && !flagged[col][row])
		{
			checked[row][col] = true;
			//verifies that a given tile does not have a mine, and then shows the relevant tile configurations
			if(!hasMine(col, row)) //it stops calling when it has a mine and instead just shows the proper color for the tile
			{
				if(row<numrows-1)
					showTiles(window, col, row+1);
				if(col<numcols-1)
					showTiles(window, col+1, row);
				if(row>0)
					showTiles(window, col, row-1);
				if(col>0)
					showTiles(window, col-1, row);
				if(col>0 && row<numrows-1)
					showTiles(window, col-1, row+1);
				if(col>0 && row>0)
					showTiles(window, col-1, row-1);
				if(col<numcols-1 && row<numrows-1)
					showTiles(window, col+1, row+1);
				if(col<numcols-1 && row>0)
					showTiles(window, col+1, row-1);
				if(getNumMines(col, row) == 0)
				{
					window.setColor(Color.GREEN);
					window.fillRect(xcoords[row][col], ycoords[row][col], boxs, boxs);
				}
			}
			//if the given tile does have a mine, it goes through this code
			else
			{
				int nummines = getNumMines(col, row);
				//it colors the tiles based on the number of mines located in a one tile radius from the tile
				switch(nummines)
				{
				case 1:
					window.setColor(Color.gray);
					window.fillRect(xcoords[row][col], ycoords[row][col], boxs, boxs);
					break;
				case 2:
					window.setColor(new Color(150, 0, 255));
					window.fillRect(xcoords[row][col], ycoords[row][col], boxs, boxs);
					break;
				case 3:
					window.setColor(Color.yellow);
					window.fillRect(xcoords[row][col], ycoords[row][col], boxs, boxs);
					break;
				case 4:
					window.setColor(new Color(175, 0, 0));
					window.fillRect(xcoords[row][col], ycoords[row][col], boxs, boxs);
					break;
				case 5:
					window.setColor(Color.blue);
					window.fillRect(xcoords[row][col], ycoords[row][col], boxs, boxs);
					break;
				case 6:
					window.setColor(Color.pink);
					window.fillRect(xcoords[row][col], ycoords[row][col], boxs, boxs);
					break;
				case 7:
					window.setColor(new Color(0,100,0));
					window.fillRect(xcoords[row][col], ycoords[row][col], boxs, boxs);
					break;
				case 8:
					window.setColor(Color.orange);
					window.fillRect(xcoords[row][col], ycoords[row][col], boxs, boxs);
					break;
				}
			}
		}
		else 
		{
			if(col == curboxx && row == curboxy)
			{
				System.out.println(curboxx+","+curboxy+" has already been checked...");
			}
			return;
		}
	}
	/**
	 * this is a function that I had for debugging and testing my code, so I could verify that it had the right output.
	 * @param window the graphics window
	 */
	public void showMines(Graphics window)
	{
		for(int row = 0; row<numrows; row++)
		{
			for(int col = 0; col<numcols; col++)
			{
				if(minethere[col][row] == true)
				{
					window.setColor(Color.RED);
					window.fillRect(xcoords[row][col], ycoords[row][col], boxs, boxs);
				}
			}
		}
	}
	/**
	 * @param col a column number in the grid
	 * @param row a row number in the grid
	 * @return int the number of mines around the tile in question
	 */
	public int getNumMines(int col, int row)
	{
		int counter = 0;
		if(row>0 && isMine(col, row-1))
		{
			counter++;
		}
		if(row<numrows-1 && isMine(col, row+1))		//they're not mutually exclusive, so I need all of them to be ifs...
		{
			counter++;
		}
		if(col>0 && isMine(col-1, row))
		{
			counter++;
		}
		if(col<numcols-1 && isMine(col+1, row))
		{
			counter++;
		}
		if(col>0 && row>0 && isMine(col-1, row-1))
		{
			counter++;
		}
		if(col<numcols-1 && row>0 && isMine(col+1, row-1))
		{
			counter++;
		}
		if(col>0 && row<numrows-1 && isMine(col-1, row+1))
		{
			counter++;
		}
		if(col<numcols-1 && row<numrows-1 && isMine(col+1, row+1))
		{
			counter++;
		}
		return counter;
	}
	/**
	 * @param col the column number in the grid
	 * @param row the row number in the grid
	 * @return boolean whether or not the tile in question has a mine
	 */
	public boolean hasMine(int col, int row)
	{
		//determines if the tile has a mine in its radius or not by checking all tiles around the tile in question
		boolean allfalse = false;
		if(row>0 && isMine(col, row-1))
		{
			return true;
		}
		if(row<numrows-1 && isMine(col, row+1))		//they're not mutually exclusive, so I need all of them to be ifs...
		{
			return true;
		}
		if(col>0 && isMine(col-1, row))
		{
			return true;
		}
		if(col<numcols-1 && isMine(col+1, row))
		{
			return true;
		}
		if(col>0 && row>0 && isMine(col-1, row-1))
		{
			return true;
		}
		if(col<numcols-1 && row>0 && isMine(col+1, row-1))
		{
			return true;
		}
		if(col>0 && row<numrows-1 && isMine(col-1, row+1))
		{
			return true;
		}
		if(col<numcols-1 && row<numrows-1 && isMine(col+1, row+1))
		{
			return true;
		}
		return allfalse;
	}
	/**
	 * @param col the column number in the grid
	 * @param row the row number in the grid
	 * @return boolean whether or not the tile in question is a mine
	 */
	public boolean isMine(int col, int row)
	{
		//checks if a given tile is a mine or not
		if(minethere[col][row])
		{
			return true;
		}
		return false;
	}

	/**
	 *detects whether the mouse is clicked
	 */
	public void mouseClicked(MouseEvent arg0) {
		System.out.println("mouse input recognized");
		//handles what happens when the mouse is clicked
		selectX = arg0.getX()+9;
		selectY = arg0.getY()+38;
		//offsets are for better accuracy
		
		if(!spacepressed)
		{
		if(selectX>xcoords[0][0] && selectX<boxs+xcoords[numcols-1][numrows-1] && selectY>ycoords[0][0] && selectY<ycoords[numcols-1][numrows-1]+boxs && setupchoices && grid && !userclicked && !minesset){
			userclicked = true;
			startcol = getBoxX();
			startrow = getBoxY();
			repaint();
		}
		if(selectX>xcoords[0][0] && selectX<boxs+xcoords[numcols-1][numrows-1] && selectY>ycoords[0][0] && selectY<ycoords[numcols-1][numrows-1]+boxs && setupchoices && grid && userclicked && minesset)
		{
			curboxx = getBoxX();
			curboxy = getBoxY();
			update = true;
			repaint();
		}
		frame.setColor(Color.GREEN);
		frame.drawRect(selectX, selectY, 10, 10);
		}
		if(SwingUtilities.isRightMouseButton(arg0))
		{
			//if spacebar is not pressed, it will just update the current box
			selectX = arg0.getX()+9;
			selectY = arg0.getY()+38;
			curboxx = getBoxX();
			curboxy = getBoxY();
			System.out.println("recognized");
			spacepressed = true;
			repaint();
		}
		needsclicked = false;
	}
	/**
	 *detects if key pressed
	 */
	public void keyPressed(KeyEvent e)
	{
		if(e.getKeyCode() == 32)
		{
			//System.out.println("key registered");
			spacepressed = true;
		}
	}
	/**
	 *detects if key released
	 */
	public void keyReleased(KeyEvent e)
	{
		if(e.getKeyCode() == 32)
		{
			spacepressed = false;
		}
	}
	/**
	 * @return int the x box of the clicked area
	 */
	public int getBoxX()
	{
		//this function returns the tile's x value (in the array)
		int returnNum = 0;
		int foundIt = 0;
		for(int col = numcols-1; col>=0; col--)
		{
			if(selectX>xcoords[0][col] && foundIt == 0)
			{
				foundIt = 1;
				returnNum = col;
			}
		}
		return returnNum;
	}
	/**
	 * @return int the y box of the clicked area
	 */
	public int getBoxY()
	{
		//this function returns the tile's y value (in the array)
		int returnNum = 0;
		int foundIt = 0;
		for(int row = numrows-1; row>=0; row--)
		{
			if(selectY>ycoords[row][0] && foundIt == 0)
			{
				foundIt = 1;
				returnNum = row;
			}
		}
		//System.out.println(returnNum);
		return returnNum;
	}
	/**
	 * @return boolean whether or not the game is complete
	 */
	public boolean checkComplete()
	{
		//checks to see if all tiles have been handled (either clicked or a mine, but essentially checked)
		for(int row = 0; row<numrows; row++)
		{
			for(int col = 0; col<numrows; col++)
			{
				if(!isMine(col,row))
				{
					if(!checked[row][col])
					{
						return false;
					}
				}
			}
		}
		return true;
	}
	/**
	 * the method that is called when the player clicks on a mine
	 * @param window the graphics window
	 */
	public void clickedMine(Graphics window)
	{
		endstatus = "You have stepped on a mine!  Game Over...";
		showMines(window); //shows all mines
	}
	/**
	 * the method that is called when the player ends the game
	 * @param window the graphics window
	 */
	public void endGame(Graphics window)
	{
		for(int row = 0; row<numrows; row++)
		{
			for(int col = 0; col<numcols; col++)
			{
				minethere[row][col] = false;
				checked[row][col] = false;
			}
		}
		JFrame frameplayagain = new JFrame();
		frameplayagain.setSize(700, 400);
		frameplayagain.pack();
		frameplayagain.setDefaultCloseOperation(EXIT_ON_CLOSE);
		frameplayagain.setLocation(400, 400);
		frameplayagain.pack();
		JOptionPane nextstep = new JOptionPane();
		int choice = 0;
		choice = JOptionPane.showConfirmDialog(frameplayagain, endstatus+"\nWould you like to play again?", null, JOptionPane.YES_NO_OPTION);
		frameplayagain.setVisible(false);
		switch(choice)
		{
		case 0:
			setVisible(false);
			new MineSweeper();
			return;
		case 1:
			setVisible(false);
			new Arcade();
			return;
		}
		
	}
	/**
	 * handles a completed game
	 * @param window the graphics window
	 */
	public void gameComplete(Graphics window)
	{
		endstatus = "You have won! Congratulations!";
		endGame(window);
	}
	/**
	 * sends the player back to the arcade
	 */
	public void backToArcade()
	{
		setVisible(false);
		new Arcade();
	}
	/**
	 *detects if mouse enters
	 */
	public void mouseEntered(MouseEvent arg0) {}
	/**
	 *detects if mouse exits
	 */
	public void mouseExited(MouseEvent arg0) {}
	/**
	 *detects if mouse pressed
	 */
	public void mousePressed(MouseEvent arg0) {}
	/**
	 *detects if mouse released
	 */
	public void mouseReleased(MouseEvent arg0) {}

	/**
	 *detects if key typed
	 */
	public void keyTyped(KeyEvent e){}
}