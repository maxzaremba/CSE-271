
public class GameCoords {
	/**
	 * the x coord
	 */
	public int x = 0;
	/**
	 * the y coord
	 */
	public int y = 0;
	/**
	 * the width
	 */
	public int w = 0;
	/**
	 * the height
	 */
	public int h = 0;
	/**
	 * the name
	 */
	public String name = "";
	/**
	 * the constructor
	 */
	public GameCoords()
	{
		
	}
	/**
	 * @param x x coord
	 * @param y y coord
	 * @param w width
	 * @param h height
	 * @param name name of the game
	 */
	public GameCoords(int x, int y, int w, int h, String name)
	{
		//create object with certain coords and then have methods to return those coordinates
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.name = name;
	}
	/**
	 * @return String the name of the game
	 */
	public String getName()
	{
		return name;
	}
	/**
	 * @return int[] the corners of the game object
	 */
	public int[] getCorners()
	{
		int[] corners = new int[4];
		corners[0] = x;
		corners[1] = y;
		corners[2] = x+w;
		corners[3] = y+h;
		return corners;
	}
}
