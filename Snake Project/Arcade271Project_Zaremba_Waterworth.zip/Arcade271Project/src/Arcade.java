import java.awt.Color;
import java.awt.Graphics;
import java.awt.MouseInfo;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
//Are we allowed to use awt?
import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.JFrame;
/**
 * @author water
 *
 */
public class Arcade extends JFrame implements MouseListener, KeyListener
{

	/**
	 * whether or not there is a click being handled
	 */
	public boolean clicked = false;
	/**
	 * whether or not the game has been selected
	 */
	public boolean gameselected = false;
	/**
	 * the frame width
	 */
	int width = 1600;
	/**
	 * the frame height
	 */
	int height = 900;
	/**
	 * the x coordinate of the mouse click
	 */
	int selectX;
	/**
	 * the y coordinate of the mouse click
	 */
	int selectY;
	/**
	 * the graphics window
	 */
	Graphics window;
	/**
	 * the list of the gamecoords
	 */
	ArrayList<GameCoords> gamelistcoords = new ArrayList<GameCoords>();
	/**
	 * The constructor, builds the frame and sets the settings
	 */
	public Arcade()
	{
		super("Arcade");
		setBackground(Color.BLACK);
		setSize(width,height);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().addMouseListener(this);
		getContentPane().addKeyListener(this);
		addKeyListener(this);
		
	}
	/**
	 *the main paint method (handles the GUI)
	 */
	public void paint(Graphics window)
	{
		this.window = window;
		int g1x = 250;
		int g1y = 150;
		int g2x = 600;
		int g2y = 150;
		int w = 250;
		int h = 500;
		window.setColor(Color.RED);
		GameCoords game1 = new GameCoords(g1x,g1y,w,h, "snake");
		gamelistcoords.add(game1);
		window.fillRect(g1x, g1y, w, h);
		window.setColor(Color.BLUE);
		GameCoords game2 = new GameCoords(g2x,g2y,w,h, "minesweeper");
		gamelistcoords.add(game2);
		window.fillRect(g2x, g2y, w, h);
		for(GameCoords each: gamelistcoords)
		{
			int[] corners = each.getCorners();
			//System.out.println(corners[0]+" "+corners[1]+" "+corners[2]+" "+corners[3]);
		}
	}
	/**
	 * @param name the name of the game
	 */
	public void chooseGame(String name)
	{
		switch(name)
		{
		case "snake":
			//run the games here and make current selector frame invisible
			SnekMain snakegame = new SnekMain();
			super.setVisible(false);
			setVisible(false);
			break;
		case "minesweeper":
			setVisible(false);
			MineSweeper game = new MineSweeper();
			super.setVisible(false);
			setVisible(false);
			break;
		}
		
	}
	/**
	 * @param x the x coord
	 * @param y the y coord
	 */
	public void checkItems(int x, int y)
	{
		for(GameCoords each:gamelistcoords)
		{
			int[] corners = each.getCorners();
			//System.out.println(Arrays.toString(corners));
			if(corners[0] < x && corners[2] > x)
			{
				if(corners[1] < y && corners[3] > y)
				{
					if(!gameselected)
					{
						chooseGame(each.getName());
						gameselected = true;
					}
				}
			}
		}

	}
	/**
	 *detects if key pressed
	 */
	public void keyPressed(KeyEvent arg0) {}
	/**
	 *detects if key released
	 */
	@Override
	public void keyReleased(KeyEvent arg0) {}
	/**
	 *detects if keytyped
	 */
	@Override
	public void keyTyped(KeyEvent arg0) {}
	/**
	 *detects if mouse clicked
	 */
	@Override
	public void mouseClicked(MouseEvent arg0) {}
	/**
	 *detects if mouse enters
	 */
	@Override
	public void mouseEntered(MouseEvent arg0) {}
	/**
	 *detects if mouse exits
	 */
	@Override
	public void mouseExited(MouseEvent arg0) {}
	/**
	 *detects if mouse pressed
	 */
	@Override
	public void mousePressed(MouseEvent arg0) {
		selectX = arg0.getX()+20;
		selectY = arg0.getY()+40;
		checkItems(selectX, selectY);
		clicked = true;
		
	}
	/**
	 *detects if mouse released
	 */
	@Override
	public void mouseReleased(MouseEvent arg0) {	}
	/**
	 * @param args the implicit parameter
	 */
	public static void main(String args[])
	{
		Arcade go = new Arcade();
	}
}